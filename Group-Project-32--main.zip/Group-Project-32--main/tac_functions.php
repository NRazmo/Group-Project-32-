<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'emailPHP-main/vendor/autoload.php';

// Restore VIGENERE_KEY constant
define('VIGENERE_KEY', 'MYSECRETKEY');

function vigenere_encrypt($plaintext, $key) {
    $key = strtoupper($key);
    $keyLength = strlen($key);
    $keyIndex = 0;
    $ciphertext = '';
    $plaintextLength = strlen($plaintext);

    for ($i = 0; $i < $plaintextLength; $i++) {
        $char = $plaintext[$i];

        if (ctype_upper($char)) {
            $keyChar = $key[$keyIndex % $keyLength];
            $offset = ord('A');
            $plainOrd = ord($char) - $offset;
            $keyOrd = ord($keyChar) - $offset;
            $cipherOrd = ($plainOrd + $keyOrd) % 26;
            $ciphertext .= chr($cipherOrd + $offset);
            $keyIndex++;
        } elseif (ctype_digit($char)) {
            $keyChar = $key[$keyIndex % $keyLength];
            $offset = ord('0');
            $plainOrd = ord($char) - $offset;
            $keyShift = ord($keyChar) - ord('A');
            $cipherOrd = ($plainOrd + $keyShift) % 10;
            $ciphertext .= chr($cipherOrd + $offset);
            $keyIndex++;
        } else {
            $ciphertext .= $char;
        }
    }
    return $ciphertext;
}

function vigenere_decrypt($ciphertext, $key) {
    $key = strtoupper($key);
    $keyLength = strlen($key);
    $keyIndex = 0;
    $plaintext = '';
    $ciphertextLength = strlen($ciphertext);

    for ($i = 0; $i < $ciphertextLength; $i++) {
        $char = $ciphertext[$i];

        if (ctype_upper($char)) {
            $keyChar = $key[$keyIndex % $keyLength];
            $offset = ord('A');
            $cipherOrd = ord($char) - $offset;
            $keyOrd = ord($keyChar) - $offset;
            $plainOrd = ($cipherOrd - $keyOrd + 260) % 26;
            $plaintext .= chr($plainOrd + $offset);
            $keyIndex++;
        } elseif (ctype_digit($char)) {
             $keyChar = $key[$keyIndex % $keyLength];
            $offset = ord('0');
            $cipherOrd = ord($char) - $offset;
            $keyShift = ord($keyChar) - ord('A');
            $plainOrd = ($cipherOrd - $keyShift + 100) % 10;
            $plaintext .= chr($plainOrd + $offset);
            $keyIndex++;
        } else {
            $plaintext .= $char;
        }
    }
    return $plaintext;
}

function sendTACEmail($email, $tacCode) {
    $mail = new PHPMailer(true);

    try {
        // Restore hardcoded email credentials in sendTACEmail()
        $server_email = 'mzuire@yahoo.co.uk';
        $server_email_pwd = 'jtaupaanqwzigomk';

        $mail->isSMTP();
        $mail->Host       = 'smtp.mail.yahoo.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = $server_email;
        $mail->Password   = $server_email_pwd;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom($server_email, 'MZMazwan Bank');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Your MZMazwan Bank TAC Code';
        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
                .header { background-color: #f8f9fa; padding: 10px; text-align: center; border-bottom: 1px solid #ddd; }
                .content { padding: 20px; }
                .tac-code {
                    font-size: 24px;
                    font-weight: bold;
                    color: #007bff;
                    text-align: center;
                    margin: 20px 0;
                    padding: 10px;
                    background-color: #e9ecef;
                    border-radius: 4px;
                    letter-spacing: 2px;
                }
                .footer { margin-top: 20px; font-size: 12px; color: #6c757d; text-align: center; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>MZMazwan Bank</h2>
                </div>
                <div class='content'>
                    <h3>Transaction Authorization Code</h3>
                    <p>Dear Customer,</p>
                    <p>Your encrypted TAC code is:</p>
                    <div class='tac-code'>$tacCode</div>
                    <p>This code is required to authorize your transaction and will expire shortly.</p>
                    <p>If you did not request this code, please ignore this email or contact our support immediately if you suspect unauthorized activity.</p>
                </div>
                <div class='footer'>
                    This is an automated message. Please do not reply to this email.
                </div>
            </div>
        </body>
        </html>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Error sending TAC email to $email: " . $mail->ErrorInfo);
        return false;
    }
}
?> 