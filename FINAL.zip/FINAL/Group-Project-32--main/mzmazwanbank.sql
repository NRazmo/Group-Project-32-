-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Apr 12, 2025 at 10:34 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mzmazwanbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `adminID` int(11) NOT NULL,
  `adminName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwordHash` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`adminID`, `adminName`, `email`, `passwordHash`) VALUES
(1, 'Admin User', 'admin@mzmazwanbank.com', 'b201c5a58220f1ddcdc6e6472f2d991a1aee544023a562497ca12ed6df6baf8f');

-- --------------------------------------------------------

--
-- Table structure for table `systemparameters`
--

CREATE TABLE `systemparameters` (
  `param_id` int(11) NOT NULL,
  `param_name` varchar(50) NOT NULL,
  `param_value` varchar(50) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `systemparameters`
--

INSERT INTO `systemparameters` (`param_id`, `param_name`, `param_value`, `last_updated`) VALUES
(1, 'login_interval_days', '11', '2025-04-12 19:59:37'),
(2, 'transfer_limit', '4000.94', '2025-04-12 19:59:59');

-- --------------------------------------------------------

--
-- Table structure for table `taccodes`
--

CREATE TABLE `taccodes` (
  `tacID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `tacCode` varchar(10) NOT NULL,
  `isUsed` tinyint(1) DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `taccodes`
--

INSERT INTO `taccodes` (`tacID`, `userID`, `tacCode`, `isUsed`, `createdAt`) VALUES
(1, 1, 'LOL69', 0, '2025-04-07 16:21:32'),
(2, 2, 'XTC87', 0, '2025-04-07 16:21:32'),
(3, 3, 'KMT54', 1, '2025-04-07 16:21:32'),
(4, 4, 'SMH67', 0, '2025-04-07 16:21:32'),


-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transactionID` int(11) NOT NULL,
  `senderID` int(11) NOT NULL,
  `receiverID` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Completed','Failed') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transactionID`, `senderID`, `receiverID`, `amount`, `transactionDate`, `status`) VALUES
(1, 1, 2, 100.50, '2025-04-07 16:21:32', 'Completed'),
(2, 2, 3, 250.00, '2025-04-07 16:21:32', 'Pending'),
(3, 3, 4, 75.25, '2025-04-07 16:21:32', 'Failed'),
(4, 4, 1, 300.00, '2025-04-07 16:21:32', 'Completed'),
(5, 1, 3, 300.00, '2025-04-07 16:22:00', 'Completed'),
(6, 1, 3, 12.00, '2025-04-07 22:44:53', 'Completed'),
(7, 1, 3, 12.00, '2025-04-08 21:58:23', 'Completed'),
(8, 1, 3, 12.00, '2025-04-08 22:35:29', 'Completed'),
(9, 1, 3, 12.00, '2025-04-10 22:45:03', 'Completed'),
(10, 3, 1, 700.00, '2025-04-12 20:21:52', 'Completed'),
(11, 3, 1, 400.00, '2025-04-12 20:27:05', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `fullName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwordHash` varchar(64) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `accountStatus` enum('Active','Blocked') DEFAULT 'Active',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastLogin` datetime NOT NULL,
  `sortCode` varchar(10) NOT NULL,
  `accountNumber` varchar(15) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `transfer_limit` decimal(10,2) DEFAULT 1000.00,
  `login_interval_days` int(11) DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `fullName`, `email`, `passwordHash`, `phoneNumber`, `address`, `accountStatus`, `createdAt`, `lastLogin`, `sortCode`, `accountNumber`, `balance`, `transfer_limit`, `login_interval_days`) VALUES
(1, 'John Doe', 'c4014473@hallam.shu.ac.uk', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', '07647875328', '17 Main Street', 'Active', '2025-04-03 20:44:15', '2025-04-12 21:08:06', '037726', '53783027', 1316.00, 2000.00, 21),
(2, 'Michael Scott', 'michael.scott@gmail.com', 'df35838dad2f9310d0544c59588331451e2ad010a283ac5acdee7fb0e35b9415', '07983627846', '99 West Avenue', 'Active', '2025-04-03 20:44:15', '2025-03-02 21:44:15', '474936', '93568369', 2456.23, 1000.00, 30),
(3, 'Pam Halpert', 'pam@gmail.com', 'bf3e7fa9d8fb943bd57c3ea0cf5e53d8dc99013d9e8d4148871717e7ab244b6a', '07374894743', '888 Tree St', 'Active', '2025-04-03 20:44:15', '2025-04-12 21:31:30', '846374', '94783947', 3378.56, 1000.00, 30),
(4, 'Lisa May', 'lisa.may@hotmail.com', '4505130ad1466311499fada2a7c5da3e92c4c2b99efd814980963e7ee51a6fae', '07925738263', '69 Road Way', 'Active', '2025-04-03 20:44:15', '2025-04-12 21:13:49', '478372', '47894637', 3250.99, 1000.00, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`adminID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `systemparameters`
--
ALTER TABLE `systemparameters`
  ADD PRIMARY KEY (`param_id`),
  ADD UNIQUE KEY `param_name` (`param_name`);

--
-- Indexes for table `taccodes`
--
ALTER TABLE `taccodes`
  ADD PRIMARY KEY (`tacID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transactionID`),
  ADD KEY `senderID` (`senderID`),
  ADD KEY `receiverID` (`receiverID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phoneNumber` (`phoneNumber`),
  ADD UNIQUE KEY `accountNumber` (`accountNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `systemparameters`
--
ALTER TABLE `systemparameters`
  MODIFY `param_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `taccodes`
--
ALTER TABLE `taccodes`
  MODIFY `tacID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `taccodes`
--
ALTER TABLE `taccodes`
  ADD CONSTRAINT `taccodes_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`senderID`) REFERENCES `users` (`userID`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`receiverID`) REFERENCES `users` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
