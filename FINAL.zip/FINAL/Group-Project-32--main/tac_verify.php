<?php
session_start();
include('connection.php');
include('tac_functions.php');

if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

$errorMessage = '';
$successMessage = '';

function requestAndSendTAC($conn, &$successMessage, &$errorMessage) {
    if (!isset($_SESSION['userID'])) {
        $errorMessage = "User session not found. Please log in again.";
        return;
    }
    $userID = $_SESSION['userID'];

    $letters = '';
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for ($i = 0; $i < 3; $i++) {
        $letters .= $alphabet[rand(0, strlen($alphabet) - 1)];
    }
    $digits = str_pad(rand(0, 99), 2, '0', STR_PAD_LEFT);

    $originalTAC = $letters . $digits;

    try {
        $stmt = $conn->prepare("SELECT email FROM Users WHERE userID = :userID");
        $stmt->bindParam(':userID', $userID);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && isset($user['email'])) {
            $userEmail = $user['email'];

            $stmt = $conn->prepare("INSERT INTO TACCodes (userID, tacCode, isUsed) VALUES (:userID, :tacCode, 0)");
            $stmt->bindParam(':userID', $userID);
            $stmt->bindParam(':tacCode', $originalTAC);
            $stmt->execute();

            $encryptedTAC = vigenere_encrypt($originalTAC, VIGENERE_KEY);

            if (sendTACEmail($user['email'], $encryptedTAC)) {
                $successMessage = "An encrypted TAC code has been sent to your email.";
            } else {
                $errorMessage = "Failed to send TAC code. Please try again.";
            }
        } else {
            $errorMessage = "User not found.";
        }
    } catch (PDOException $e) {
        error_log("Database error in tac_verify.php requestAndSendTAC: " . $e->getMessage());
        $errorMessage = "Database error. Please try again later.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    requestAndSendTAC($conn, $successMessage, $errorMessage);
}

if (isset($_GET['type']) && $_GET['type'] === 'transfer') {
    // Verify TAC for transfer
    if (verifyTAC($conn, $_SESSION['userID'], $_POST['tac'])) {
        // Process the pending transfer
        if (isset($_SESSION['pending_transfer'])) {
            $transfer = $_SESSION['pending_transfer'];
            processTransfer(
                $conn, 
                $_SESSION['userID'], 
                $transfer['recipientID'], 
                $transfer['amount'], 
                $transfer['description']
            );
            unset($_SESSION['pending_transfer']);
            header("Location: transfer_verify.php?success=1");
            exit();
        }
    } else {
        $error = "Invalid TAC code";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['request_tac'])) {
        requestAndSendTAC($conn, $successMessage, $errorMessage);
    }
    else if (isset($_POST['verify_tac']) && isset($_POST['tac_code']) && !empty($_POST['tac_code'])) {
        $enteredEncryptedTAC = trim($_POST['tac_code']);

        if (!isset($_SESSION['userID'])) {
             $errorMessage = "User session not found. Please log in again.";
        } else {
            $userID = $_SESSION['userID'];

            try {
                $stmt = $conn->prepare("SELECT tacCode FROM TACCodes WHERE userID = :userID AND isUsed = 0 ORDER BY createdAt DESC LIMIT 1");
                $stmt->bindParam(':userID', $userID);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($result) {
                    $storedOriginalTAC = $result['tacCode'];

                    if (!defined('VIGENERE_KEY')) {
                         $errorMessage = "Configuration error. Please contact support.";
                         error_log("[Verify TAC] FATAL ERROR: VIGENERE_KEY constant not defined!");
                    } else {
                        $currentKey = VIGENERE_KEY;
                        $decryptedEnteredTAC = vigenere_decrypt($enteredEncryptedTAC, $currentKey);

                        if ($decryptedEnteredTAC === $storedOriginalTAC) {
                            $updateStmt = $conn->prepare("UPDATE TACCodes SET isUsed = 1 WHERE userID = :userID AND tacCode = :tacCode AND isUsed = 0 ORDER BY createdAt DESC LIMIT 1");
                            $updateStmt->bindParam(':userID', $userID);
                            $updateStmt->bindParam(':tacCode', $storedOriginalTAC);
                            $updateStmt->execute();

                            $_SESSION['tac_verified'] = true;
                            $_SESSION['tac_verified_time'] = time();

                            header("Location: dashboard.php");
                            exit();
                        } else {
                            $errorMessage = "Invalid or expired TAC code.";
                        }
                    }
                } else {
                    $errorMessage = "Invalid or expired TAC code.";
                }
            } catch (PDOException $e) {
                error_log("[Verify TAC] Database error during verification: " . $e->getMessage());
                $errorMessage = "Database Error during verification. Please try again later.";
            }
        }
    } else if (isset($_POST['verify_tac'])) {
         $errorMessage = "Please enter the TAC code.";
    }
}

function checkIfTACRequired($conn, $userID, $transferAmount = 0) {
    try {
        // Get user's specific settings
        $stmt = $conn->prepare("
            SELECT transfer_limit, login_interval_days, lastLogin 
            FROM Users 
            WHERE userID = :userID
        ");
        $stmt->bindParam(':userID', $userID);
        $stmt->execute();
        $userSettings = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$userSettings) {
            return false;
        }

        // Check login interval
        $lastLogin = new DateTime($userSettings['lastLogin']);
        $now = new DateTime();
        $interval = $now->diff($lastLogin);
        $daysSinceLastLogin = $interval->days;

        if ($daysSinceLastLogin >= $userSettings['login_interval_days']) {
            return true; // TAC required due to login interval
        }

        // Check transfer amount
        if ($transferAmount > $userSettings['transfer_limit']) {
            return true; // TAC required due to transfer amount
        }

        return false; // No TAC required
    } catch (Exception $e) {
        error_log("Error checking TAC requirement: " . $e->getMessage());
        return false;
    }
}

// Example usage in your login verification:
if (checkIfTACRequired($conn, $_SESSION['userID'])) {
    // Redirect to TAC verification page
    header("Location: tac_verify.php");
    exit();
}

// Example usage in your transfer verification:
if (isset($_SESSION['transfer_data']) && isset($_SESSION['transfer_data']['amount'])) {
    $transferAmount = $_SESSION['transfer_data']['amount'];
    if (checkIfTACRequired($conn, $_SESSION['userID'], $transferAmount)) {
        // Redirect to TAC verification page
        header("Location: tac_verify.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAC Verification - MZMazwan Banking</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .tac-inputs-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        .tac-digit-input {
            width: 40px;
            height: 50px;
            text-align: center;
            font-size: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-transform: uppercase;
        }
        .tac-digit-input::-webkit-outer-spin-button,
        .tac-digit-input::-webkit-inner-spin-button {
            -webkit-appearance: none; margin: 0;
        }
        .tac-digit-input[type=number] { -moz-appearance: textfield; }
    </style>
</head>
<body>

    <div class="login-box">
        <?php if ($successMessage): ?>
            <div class="success"><?php echo htmlspecialchars($successMessage); ?></div>
        <?php endif; ?>

        <?php if ($errorMessage): ?>
            <div class="error"><?php echo htmlspecialchars($errorMessage); ?></div>
        <?php endif; ?>

        <form method="post" id="tac-form">
            <div>
                <label for="tac-digit-1">Enter Encrypted TAC Code:</label>
                <div class="tac-inputs-container">
                    <input type="text" id="tac-digit-1" class="tac-digit-input" maxlength="1" required style="text-transform: uppercase;">
                    <input type="text" class="tac-digit-input" maxlength="1" required style="text-transform: uppercase;">
                    <input type="text" class="tac-digit-input" maxlength="1" required style="text-transform: uppercase;">
                    <input type="text" class="tac-digit-input" maxlength="1" required style="text-transform: uppercase;">
                    <input type="text" class="tac-digit-input" maxlength="1" required style="text-transform: uppercase;">
                </div>
                <input type="hidden" name="tac_code" id="tac_code_hidden">
            </div>
            <div>
                <button type="submit" name="verify_tac">Verify TAC</button>
                <button type="submit" name="request_tac" formnovalidate>Request New TAC</button>
            </div>
        </form>
    </div>

    <script>
        const tacInputs = document.querySelectorAll('.tac-digit-input');
        const hiddenInput = document.getElementById('tac_code_hidden');
        const tacForm = document.getElementById('tac-form');
        const expectedLength = 5;

        tacInputs.forEach((input, index) => {
             input.addEventListener('input', (e) => {
                input.value = input.value.toUpperCase();

                if (input.value.length === 1 && index < tacInputs.length - 1) {
                    tacInputs[index + 1].focus();
                }
                updateHiddenInput();
            });

            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && input.value.length === 0 && index > 0) {
                    tacInputs[index - 1].focus();
                }
                 if (e.key === 'Backspace' || e.key === 'Delete') {
                     setTimeout(updateHiddenInput, 0);
                 }
            });

             input.addEventListener('paste', (e) => {
                e.preventDefault();
                const pasteData = e.clipboardData.getData('text').replace(/\s+/g, '').trim().toUpperCase();
                if (/^[A-Z0-9]+$/.test(pasteData)) {
                    let currentInput = index;
                    for (let i = 0; i < pasteData.length && currentInput < tacInputs.length; i++) {
                        tacInputs[currentInput].value = pasteData[i];
                         if (currentInput < tacInputs.length - 1) {
                             tacInputs[currentInput + 1].focus();
                         }
                        currentInput++;
                    }
                    updateHiddenInput();
                }
            });
        });

        function updateHiddenInput() {
            let combinedValue = '';
            tacInputs.forEach(input => {
                combinedValue += input.value;
            });
            hiddenInput.value = combinedValue;
        }

        tacForm.addEventListener('submit', (e) => {
             if (document.activeElement && document.activeElement.name === 'request_tac') {
                 return;
             }
            updateHiddenInput();
            if (hiddenInput.value.length !== expectedLength) {
            }
        });

    </script>

</body>
</html>
